package com.ia;


import android.Manifest;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.IBinder;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.TimeZone;


public class BackgroundProcess extends Service implements RecognitionListener{

    private SpeechRecognizer speechRecognizer;

    public DatabaseManager dM;

    //Note, the user has to speak in yyyy/mm/dd, task format.
    //Single digits have to be spoken like 0 - number.
    //Year has to be spoken in x-thousand and x. Eg. Two thousand and twenty three
    //Pauses cannot be too long in between the words, or the input may be buggy.

    @Override
    public void onCreate() {
        super.onCreate();
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(this);
        dM = new DatabaseManager(this);

    }

    private void startSpeechRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizer.startListening(intent);
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Please grant microphone permission.", Toast.LENGTH_SHORT).show();
            stopSelf(); // Stop the service if permission is not granted
        } else {
            startSpeechRecognition();
        }
        return START_STICKY; // Service will be restarted if it gets killed by the system
    }

    @Override
    public void onDestroy() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onReadyForSpeech(Bundle bundle) {

    }

    @Override
    public void onBeginningOfSpeech() {

    }

    @Override
    public void onRmsChanged(float v) {

    }

    @Override
    public void onBufferReceived(byte[] bytes) {

    }

    @Override
    public void onEndOfSpeech() {

    }

    @Override
    public void onError(int i) {

    }

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> speechResults = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        String task = "";
        String date = "";
        Calendar scheduledTime = Calendar.getInstance(TimeZone.getTimeZone("Asia/Hong_Kong"));
        if (speechResults != null && !speechResults.isEmpty()) {
            String input = speechResults.get(0); //Whole input is one string
            input = input.replaceAll(" ", "/");
            String[] wordsArray = input.split("/");
            ArrayList<String> processedSpeechResults = new ArrayList<>(Arrays.asList(wordsArray)); //String is split into multiple elements in another array
            for (int i = 0; i<5; i++){
                date = date + processedSpeechResults.get(i) + " ";
            }
            for (int i = 5; i < processedSpeechResults.size(); i++) {
                task = task + processedSpeechResults.get(i) + " ";
            }
            try{
                dM.insertTask(task, date);
                scheduledTime.set(Calendar.YEAR, Integer.parseInt(processedSpeechResults.get(0)));
                scheduledTime.set(Calendar.MONTH, Integer.parseInt(processedSpeechResults.get(1))-1);
                scheduledTime.set(Calendar.DAY_OF_MONTH, Integer.parseInt(processedSpeechResults.get(2))); //Day of month recognizes the month integer as one higher.
                scheduledTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(processedSpeechResults.get(3)));
                scheduledTime.set(Calendar.MINUTE, Integer.parseInt(processedSpeechResults.get(4)));
                scheduledTime.set(Calendar.SECOND, 0);
                scheduledTime.set(Calendar.MILLISECOND, 0);
                NotificationCreator.createNotification(this, scheduledTime, "Task reminder", task);
            }
            catch (NumberFormatException e){
                Toast.makeText(this, "False input.", Toast.LENGTH_SHORT).show();
            }
            catch (NullPointerException e){
                Toast.makeText(this, "False input.", Toast.LENGTH_SHORT).show();
            }

        }
    }

    @Override
    public void onPartialResults(Bundle bundle) {

    }

    @Override
    public void onEvent(int i, Bundle bundle) {

    }
}
