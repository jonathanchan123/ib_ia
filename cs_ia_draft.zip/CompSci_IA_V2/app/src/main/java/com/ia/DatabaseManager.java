package com.ia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DatabaseManager extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "task_database";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "task_table";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_TASK = "task";

    public static final String COLUMN_STATUS = "status";

    public SQLiteDatabase dB;



    public DatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase dB) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_TASK + " TEXT PRIMARY KEY," +
                COLUMN_DATE + " TEXT, " +
                COLUMN_STATUS + " TEXT)";
        dB.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase dB, int oldVersion, int newVersion) {
        // Handle schema upgrades if needed
    }

    public void openDatabase(){
        dB = this.getWritableDatabase();
    }

    public Boolean insertTask(String task, String date){
        dB = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TASK, task);
        cv.put(COLUMN_STATUS, "0");
        cv.put(COLUMN_DATE, date);
        long row = dB.insert(TABLE_NAME, null, cv);
        if (row == -1){
            return false;
        }
        else{
            return true;
        }
    }

    public void deleteTask(Context context, String deletedTask){
        dB = this.getWritableDatabase();

        String[] columns = {COLUMN_TASK};
        String selection = COLUMN_TASK + " = ?";
        String[] selectionArgs = {deletedTask};
        Cursor cursor = dB.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        int uniqueId = -1;
        if (cursor.moveToFirst()) {
            uniqueId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TASK));
        }
        cursor.close();

        // Cancel the scheduled notification
        if (uniqueId != -1) {
            NotificationCreator.cancelNotification(context, uniqueId);
        }


        String whereClause = COLUMN_TASK + " = ?";
        String[] whereArgs = {deletedTask};
        int rowsDeleted = dB.delete(TABLE_NAME, whereClause, whereArgs);
        if (rowsDeleted > 0){

        }
        else{
            //False Deletion, for debugging purposes
        }
    }

    public SQLiteDatabase getDataBase(){
        return dB;
    }

    public Cursor getData(){
        dB = this.getWritableDatabase();
        Cursor cursor = dB.rawQuery("Select * from task_table", null);
        return cursor;
    }
}

