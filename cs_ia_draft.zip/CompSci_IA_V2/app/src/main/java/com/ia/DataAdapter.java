package com.ia;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    public Context context;
    public List<String> Task_ID;
    public List<String> Date_ID;
    public List<String> Status_ID;
    public OnItemClickListener deleteListener;
    private DatabaseManager dM;

    public interface OnItemClickListener{
        void onItemDelete(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        deleteListener = listener;
    }

    public DataAdapter(Context context, List<String> Task_ID, List<String> Date_ID, List<String> Status_ID, OnItemClickListener listener) {
        this.context = context;
        this.Task_ID = Task_ID;
        this.Date_ID = Date_ID;
        this.Status_ID = Status_ID;
        this.dM = dM;
        this.deleteListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new ViewHolder(view, deleteListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.Task_ID.setText(Task_ID.get(position));
        holder.Date_ID.setText(Date_ID.get(position));
        holder.Status_ID.setText(Status_ID.get(position));
    }


    @Override
    public int getItemCount(){
        if (Date_ID != null){
            return Date_ID.size();
        }
        else {
            return 0;
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView Task_ID;
        public TextView Date_ID;
        public TextView Status_ID;
        public Button buttonDelete;

        public ViewHolder(View itemView, OnItemClickListener listener) {
            super(itemView);
            Task_ID = itemView.findViewById(R.id.textTask);
            Date_ID = itemView.findViewById(R.id.textDate);
            Status_ID = itemView.findViewById(R.id.textStatus);
            buttonDelete = itemView.findViewById(R.id.deleteButton);
            buttonDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            listener.onItemDelete(position);
                        }
                    }
                }
            });
        }
    }
}

