package com.ia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;


public class viewscreen extends AppCompatActivity implements DataAdapter.OnItemClickListener {
    public RecyclerView recyclerView;
    public ArrayList<String> task;
    public ArrayList<String> date;
    public ArrayList<String> status;
    public DatabaseManager dM;
    public DataAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewscreen);
        dM = new DatabaseManager(this);
        task = new ArrayList<>();
        date = new ArrayList<>();
        status = new ArrayList<>();
        recyclerView = findViewById(R.id.RecyclerView);
        adapter = new DataAdapter(this, task, date, status, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter.setOnItemClickListener(this);
        displayData();
    }

    private void displayData() {
        Cursor cursor = dM.getData();
        if (cursor.getCount()==0){
            Toast.makeText(this,"No entry exists.", Toast.LENGTH_SHORT).show();
            return;
        }
        else {
            while (cursor.moveToNext()) {
                task.add(cursor.getString(0));
                date.add(cursor.getString(1));
                status.add(cursor.getString(2));
            }
        }
    }

    @Override
    public void onItemDelete(int position) {
        String taskToDelete = task.get(position);
        dM.deleteTask(this, taskToDelete);

        // Remove the item from the ArrayLists
        task.remove(position);
        date.remove(position);
        status.remove(position);

        // Notify the adapter about the item removal
        adapter.notifyItemRemoved(position);
    }
}
